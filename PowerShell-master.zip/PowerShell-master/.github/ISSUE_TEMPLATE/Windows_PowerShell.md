---
name: Windows PowerShell
about: Windows PowerShell issues/suggestions need to be reported to [UserVoice](https://windowsserver.uservoice.com/forums/301869-powershell)
labels: Issue-Question
assignees: ''

---

# Windows PowerShell

For Windows PowerShell 5.1 issues, suggestions, or feature requests please use the following link instead:
Windows PowerShell [UserVoice](https://windowsserver.uservoice.com/forums/301869-powershell)

This repository is **ONLY** for PowerShell Core 6 issues.
